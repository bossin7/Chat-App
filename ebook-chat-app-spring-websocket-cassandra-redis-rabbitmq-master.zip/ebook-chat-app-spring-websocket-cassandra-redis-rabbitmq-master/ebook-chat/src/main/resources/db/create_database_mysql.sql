CREATE DATABASE ebook_chat;
